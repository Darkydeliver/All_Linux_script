#!/bin/bash

# Define variables
cert_filename="rootCA.crt"
key_filename="rootCA.key"
output_dir="./Linux_output/Defence_Evasion"
output_file="${output_dir}/T1553.004_Defence_evasion.txt"

# Function to detect the operating system
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo "$ID"
    else
        echo "unknown"
    fi
}

# Function to install root CA on CentOS/RHEL/Oracle
install_ca_centos_rhel_oracle() {
    echo "Installing root CA on CentOS/RHEL/Oracle..."
    cp "${cert_filename}" /etc/pki/ca-trust/source/anchors/
    update-ca-trust
}

# Function to install root CA on FreeBSD
install_ca_freebsd() {
    echo "Installing root CA on FreeBSD..."
    cp "${cert_filename}" /usr/local/share/certs/
    certctl rehash
}

# Function to install root CA on Debian/Ubuntu
install_ca_debian_ubuntu() {
    echo "Installing root CA on Debian/Ubuntu..."
    mv "${cert_filename}" /usr/local/share/ca-certificates/
    update-ca-certificates
}

# Function to install root CA on Fedora
install_ca_fedora() {
    echo "Installing root CA on Fedora..."
    cp "${cert_filename}" /etc/pki/ca-trust/source/anchors/
    update-ca-trust
}

# Function to install root CA on Arch Linux
install_ca_arch_linux() {
    echo "Installing root CA on Arch Linux..."
    cp "${cert_filename}" /usr/local/share/ca-certificates/
    update-ca-certificates
}

# Function to install dependencies based on OS
install_dependencies() {
    local os=$(detect_os)

    if [[ "$os" == "ubuntu" || "$os" == "debian" ]]; then
        echo "Installing dependencies for Ubuntu/Debian..."
        sudo apt update
        sudo apt install -y openssl ca-certificates
    elif [[ "$os" == "rhel" || "$os" == "centos" || "$os" == "oracle" || "$os" == "fedora" ]]; then
        echo "Installing dependencies for RHEL/CentOS/Oracle/Fedora..."
        sudo yum install -y openssl ca-certificates
    elif [[ "$os" == "arch" ]]; then
        echo "Installing dependencies for Arch Linux..."
        sudo pacman -Syu --noconfirm openssl ca-certificates
    else
        echo "Unsupported OS: $os. Please install dependencies manually."
        exit 1
    fi
}

# Function to generate key and certificate
generate_cert() {
    openssl genrsa -out "${key_filename}" 4096
    openssl req -x509 -new -nodes -key "${key_filename}" -sha256 -days 365 -subj "/C=US/ST=Denial/L=Springfield/O=Dis/CN=www.example.com" -out "${cert_filename}"
}

# Function to clean up
cleanup() {
    echo "Cleaning up..."
    if [[ -f "/etc/pki/ca-trust/source/anchors/${cert_filename}" ]]; then
        rm "/etc/pki/ca-trust/source/anchors/${cert_filename}"
        update-ca-trust
    fi
    if [[ -f "/usr/local/share/certs/${cert_filename}" ]]; then
        rm "/usr/local/share/certs/${cert_filename}"
        certctl rehash
    fi
    if [[ -f "/usr/local/share/ca-certificates/${cert_filename}" ]]; then
        rm "/usr/local/share/ca-certificates/${cert_filename}"
        update-ca-certificates
    fi
}

# Main script logic
if [[ "$1" == "cleanup" ]]; then
    cleanup
    exit 0
fi

# Check for prerequisites and generate certificate if necessary
if [[ ! -f "${cert_filename}" ]]; then
    echo "Generating root CA certificate and key..."
    generate_cert
fi

# Install dependencies for the respective OS
install_dependencies

# Redirect all output to the output file
{
    # Print command being executed
    echo "\$ bash T1553.004_Defence_evasion.sh"
    echo ""

    # Generate certificate and install root CA based on the OS
    generate_cert
    local os=$(detect_os)
    if [[ "$os" == "rhel" || "$os" == "centos" || "$os" == "oracle" ]]; then
        install_ca_centos_rhel_oracle
    elif [[ "$os" == "freebsd" ]]; then
        install_ca_freebsd
    elif [[ "$os" == "ubuntu" || "$os" == "debian" ]]; then
        install_ca_debian_ubuntu
    elif [[ "$os" == "fedora" ]]; then
        install_ca_fedora
    elif [[ "$os" == "arch" ]]; then
        install_ca_arch_linux
    else
        echo "Unsupported operating system."
        exit 1
    fi

    echo "Root CA installation completed."
} > "${output_file}" 2>&1  # Redirect both stdout and stderr to the output file

echo "Output saved to: ${output_file}"

