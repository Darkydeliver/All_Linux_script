#!/bin/bash

# Variables
module_name="T1547006"
module_path="/tmp/T1547.006/$module_name.ko"
temp_folder="/tmp/T1547.006"

# Kernel module source code
kernel_module_code='
#include <linux/module.h>
#include <linux/kernel.h>

int init_module(void) {
    printk(KERN_INFO "Hello, world\n");
    return 0;
}

void cleanup_module(void) {
    printk(KERN_INFO "Goodbye, world\n");
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Simple Kernel Module");
MODULE_AUTHOR("OpenAI");
'

# Makefile for kernel module
makefile_code='
obj-m += T1547006.o

all:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules

clean:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean
'

# Function to install kernel headers if not present
function install_kernel_headers {
    local kernel_version=$(uname -r)

    # Detect the package manager and install kernel headers accordingly
    if command -v apt-get &> /dev/null; then
        if ! dpkg -l | grep -q linux-headers-$kernel_version; then
            echo "Kernel headers not found. Installing..."
            sudo apt update
            if ! sudo apt install -y linux-headers-$kernel_version; then
                echo "Specific headers package not found. Trying to install generic headers..."
                if ! sudo apt install -y linux-headers-generic; then
                    echo "Failed to install kernel headers. Exiting."
                    exit 1
                fi
            fi
        else
            echo "Kernel headers already installed."
        fi
    elif command -v yum &> /dev/null; then
        if ! rpm -qa | grep -q kernel-headers; then
            echo "Kernel headers not found. Installing..."
            sudo yum install -y kernel-headers
        else
            echo "Kernel headers already installed."
        fi
    elif command -v dnf &> /dev/null; then
        if ! rpm -qa | grep -q kernel-headers; then
            echo "Kernel headers not found. Installing..."
            sudo dnf install -y kernel-headers
        else
            echo "Kernel headers already installed."
        fi
    else
        echo "No supported package manager found. Exiting."
        exit 1
    fi
}

# Function to load kernel module
function load_kernel_module {
    if [ ! -f "$module_path" ]; then
        echo "Kernel module not found at $module_path, compiling..."
        compile_kernel_module
    else
        echo "Kernel module found at $module_path, loading..."
    fi

    sudo insmod "$module_path"

    if lsmod | grep "$module_name"; then
        echo "Kernel module $module_name loaded successfully."
    else
        echo "Failed to load kernel module $module_name."
    fi
}

# Function to compile kernel module
function compile_kernel_module {
    if [ ! -d "$temp_folder" ]; then
        mkdir -p "$temp_folder"
        touch "$temp_folder/safe_to_delete"
    fi

    echo "$kernel_module_code" > "$temp_folder/$module_name.c"
    echo -e "$makefile_code" > "$temp_folder/Makefile"
    cd "$temp_folder" || exit
    make

    if [ -f "$temp_folder/$module_name.ko" ]; then
        mv "$temp_folder/$module_name.ko" "$module_path"
    else
        echo "Compilation failed. Kernel module not found."
        exit 1
    fi
}

# Function to clean up kernel module and temporary files
function cleanup {
    sudo rmmod "$module_name"
    if [ -f "$temp_folder/safe_to_delete" ]; then
        rm -rf "$temp_folder"
    fi
    echo "Cleanup completed."
}

# Main script logic to execute chosen test
echo "Executing T1547.006 - SISA Test..."

# Ensure kernel headers are installed
install_kernel_headers

# Load kernel module
load_kernel_module

echo "All chosen atomic tests executed."

# Cleanup
cleanup


