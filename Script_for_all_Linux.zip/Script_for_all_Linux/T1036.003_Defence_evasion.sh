#!/bin/bash

# Directories
output_dir="./Linux_output/Defence_Evasion"
output_file="$output_dir/T1036.003_output.txt"

# Ensure the output directory exists
mkdir -p "$output_dir"

# Redirect all output to the output file
exec > >(tee -a "$output_file") 2>&1

# Atomic Test: T1036.003 - Masquerading as FreeBSD or Linux crond process

# Check if the script is run with sudo/root permissions
if [[ "$EUID" -ne 0 ]]; then
    echo "This script must be run as root or with sudo privileges."
    exit 1
fi

# Copy /bin/sh to /tmp/crond
cp /bin/sh /tmp/crond

# Modify permissions to make /tmp/crond executable
chmod +x /tmp/crond

# Print information to mimic crond process status
echo "Starting crond service..."

# Backup the current crontab file before modifying
crontab_backup="/etc/crontab.bak"
cp /etc/crontab "$crontab_backup"

# Simulate a cron job by appending a command to crontab
echo '* * * * * root /tmp/crond' >> /etc/crontab

# Run /tmp/crond with a simple command (e.g., sleep 5)
echo 'sleep 5' | /tmp/crond

# Clean up: remove /tmp/crond and remove crontab entry
rm /tmp/crond
sed -i '/\/tmp\/crond/d' /etc/crontab

# Print completion message
echo "Masquerading as crond completed."

# Display a message indicating that the output has been saved
echo "Script executed and completed. Detailed output is stored in $output_file."

# Restore the original crontab file
mv "$crontab_backup" /etc/crontab

