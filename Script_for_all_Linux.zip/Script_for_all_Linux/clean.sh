# T1040 Cleanup
echo "T1040 cleanup"
program_name="linux_pcapdemo"
program_c_file="/tmp/${program_name}.c"
program_executable="/tmp/${program_name}"

echo "Cleaning up..."
rm -f $program_c_file
if [ $? -eq 0 ]; then echo "$program_c_file removed successfully"; else echo "Failed to remove $program_c_file"; fi
rm -f $program_executable
if [ $? -eq 0 ]; then echo "$program_executable removed successfully"; else echo "Failed to remove $program_executable"; fi
echo "Cleanup completed."
#------------------------------------------------------

# T1053.003 -Execution.sh
echo "T1053.003 - Execution Cleanup"
echo "Test 1 Cleanup"
crontab /tmp/notevil
if [ $? -eq 0 ]; then echo "Crontab set successfully"; else echo "Failed to set crontab"; fi

echo "Test 2 Cleanup"
cron_script_name_SISA_2="persistevil"

rm /etc/cron.daily/${cron_script_name_SISA_2} -f
if [ $? -eq 0 ]; then echo "/etc/cron.daily/${cron_script_name_SISA_2} removed successfully"; else echo "Failed to remove /etc/cron.daily/${cron_script_name_SISA_2}"; fi
rm /etc/cron.hourly/${cron_script_name_SISA_2} -f
if [ $? -eq 0 ]; then echo "/etc/cron.hourly/${cron_script_name_SISA_2} removed successfully"; else echo "Failed to remove /etc/cron.hourly/${cron_script_name_SISA_2}"; fi
rm /etc/cron.monthly/${cron_script_name_SISA_2} -f
if [ $? -eq 0 ]; then echo "/etc/cron.monthly/${cron_script_name_SISA_2} removed successfully"; else echo "Failed to remove /etc/cron.monthly/${cron_script_name_SISA_2}"; fi
rm /etc/cron.weekly/${cron_script_name_SISA_2} -f
if [ $? -eq 0 ]; then echo "/etc/cron.weekly/${cron_script_name_SISA_2} removed successfully"; else echo "Failed to remove /etc/cron.weekly/${cron_script_name_SISA_2}"; fi

echo "Test 3 Cleanup "
cron_script_name_SISA_3="persistevil"
rm /etc/cron.d/${cron_script_name_SISA_3} -f
if [ $? -eq 0 ]; then echo "/etc/cron.d/${cron_script_name_SISA_3} removed successfully"; else echo "Failed to remove /etc/cron.d/${cron_script_name_SISA_3}"; fi

echo "Test 4 Cleanup "
rm /var/spool/cron/crontabs/${cron_script_name_SISA_3} -f
if [ $? -eq 0 ]; then echo "/var/spool/cron/crontabs/${cron_script_name_SISA_3} removed successfully"; else echo "Failed to remove /var/spool/cron/crontabs/${cron_script_name_SISA_3}"; fi
#----------------------------------------------------------------

# T1053.006 Cleanup
echo "T1053.006 Cleanup"
path_to_systemd_service="/etc/systemd/system/sisa-timer.service"
path_to_systemd_timer="/etc/systemd/system/sisa-timer.timer"
systemd_service_name="sisa-timer.service"
systemd_timer_name="sisa-timer.timer"

systemctl stop ${systemd_timer_name}
if [ $? -eq 0 ]; then echo "${systemd_timer_name} stopped successfully"; else echo "Failed to stop ${systemd_timer_name}"; fi
systemctl disable ${systemd_timer_name}
if [ $? -eq 0 ]; then echo "${systemd_timer_name} disabled successfully"; else echo "Failed to disable ${systemd_timer_name}"; fi

rm ${path_to_systemd_service}
if [ $? -eq 0 ]; then echo "${path_to_systemd_service} removed successfully"; else echo "Failed to remove ${path_to_systemd_service}"; fi
rm ${path_to_systemd_timer}
if [ $? -eq 0 ]; then echo "${path_to_systemd_timer} removed successfully"; else echo "Failed to remove ${path_to_systemd_timer}"; fi

systemctl daemon-reload
#-----------------------------------------------------------------


# Exfiltration Cleanup
echo "Exfiltration Cleanup"
HOSTNAME=$(hostname)
ZIPPED_FILE="${HOSTNAME}.zip"

rm ${ZIPPED_FILE}
if [ $? -eq 0 ]; then echo "${ZIPPED_FILE} removed successfully"; else echo "Failed to remove ${ZIPPED_FILE}"; fi
rm "Exfildata.txt"
if [ $? -eq 0 ]; then echo "Exfildata.txt removed successfully"; else echo "Failed to remove Exfildata.txt"; fi
rm "Exfiltrated_data.zip"
if [ $? -eq 0 ]; then echo "Exfiltrated_data.zip removed successfully"; else echo "Failed to remove Exfiltrated_data.zip"; fi
rm "passwd.zip"
if [ $? -eq 0 ]; then echo "passwd.zip removed successfully"; else echo "Failed to remove passwd.zip"; fi

echo "Removed zip files"
echo ""

# Deleting users
# Define the users to check
USERS=("Bastest" "testuser" "art" "SISABAS")

# Loop through each user
for user in "${USERS[@]}"; do
    if getent passwd "$user" > /dev/null; then
        echo "User $user exists. Deleting..."
        sudo userdel -r "$user" && echo "User $user and their home directory have been deleted." || echo "Failed to delete user $user."
    else
        echo "User $user does not exist."
    fi
done


# T1548.001_Defence_evasion.sh
echo "T1548.001 cleanup"

# Function for SISA Test #1 - Make and modify binary from C source
sudo rm /tmp/hello
sudo rm /tmp/hello.c

# Function for SISA Test #3 - Set a SetUID flag on file
file_to_setuid="/tmp/evilBinary"
sudo rm "${file_to_setuid}"

# Function for SISA Test #5 - Set a SetGID flag on file
file_to_setgid="/tmp/evilBinary"
sudo rm "${file_to_setgid}"

# Function for SISA Test #7 - Make and modify capabilities of a binary
rm /tmp/cap
rm /tmp/cap.c

# Function for SISA Test #8 - Provide the SetUID capability to a file
file_to_setcap="/tmp/evilBinary"
rm "${file_to_setcap}" "
echo "cleanup completed"
echo ""

#---------------------------------------------------------

#T1113
echo "T1113 cleanup"

output_dir="Linux_output/Collection"
screenshot_dir="${output_dir}/T1113_Collection_screenshots"
sudo rm "$screenshot_dir"

#-----------------------------------------
#T1098.004_Privilege_Escalation.sh
echo "T1098.004 cleanup"
unset ssh_authorized_keys
#------------------------------------------

output_file="$output_folder/T1074.001_Collection.txt"
rm "${output_file}"

#--------------------------------

#clearing Tmp 
sudo rm -r /tmp/
