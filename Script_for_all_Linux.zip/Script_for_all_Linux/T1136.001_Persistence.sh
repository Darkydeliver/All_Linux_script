#!/bin/bash

# Define the path for Linux_output directory
LinuxOutputDir="$(pwd)/Linux_output"

# Ensure Linux_output directory exists
mkdir -p "$LinuxOutputDir"

# Define the path for Persistence directory
PathToAtomicsFolder="$LinuxOutputDir/Persistence"

# Ensure Persistence directory exists
mkdir -p "$PathToAtomicsFolder"

# Define the path for T1136.001_Persistence directory
AtomicFolder="$PathToAtomicsFolder/T1136.001_Persistence"

# Ensure T1136.001_Persistence directory exists
mkdir -p "$AtomicFolder"

# Define output text file path
OutputLogFile="$AtomicFolder/T1136.001_Persistence.txt"

# Define default values for user creation
DEFAULT_USERNAME="evil_user"
DEFAULT_PASSWORD="BetterWithButter"

# Function to log output to both the terminal and the log file
function log_output {
    local message="$1"
    echo "$message" | tee -a "$OutputLogFile"
}

# Function to create a user on Linux using useradd
function create_linux_user {
    local username=$1
    log_output "Creating user $username on Linux..."
    sudo useradd -M -N -r -s /bin/bash -c "evil_account $username" "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        log_output "Linux user $username created successfully."
    else
        log_output "Failed to create Linux user $username."
    fi
}

# Function to clean up Linux user
function cleanup_linux_user {
    local username=$1
    log_output "Cleaning up Linux user $username..."
    sudo userdel "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        log_output "Linux user $username deleted successfully."
    else
        log_output "Failed to delete Linux user $username."
    fi
}

# Function to create a Linux user with root UID and GID
function create_linux_user_with_root_gid {
    local username=$1
    local password=$2
    log_output "Creating Linux user $username with root UID and GID..."
    sudo useradd -g 0 -M -d /root -s /bin/bash "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "$username:$password" | sudo chpasswd
        log_output "Linux user $username created and password set."
    else
        log_output "Failed to create Linux user $username."
    fi
}

# Function to clean up Linux user with root UID and GID
function cleanup_linux_user_with_root_gid {
    local username=$1
    log_output "Cleaning up Linux user $username with root UID and GID..."
    sudo userdel "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        log_output "Linux user $username deleted successfully."
    else
        log_output "Failed to delete Linux user $username."
    fi
}

# Function to detect the distribution and handle package manager for package installation
function detect_distribution {
    if grep -iq "debian\|ubuntu\|kali\|mint" /usr/lib/os-release; then
        DISTRO="Debian-based"
    elif grep -iq "redhat\|centos\|fedora\|oracle" /usr/lib/os-release; then
        DISTRO="Red Hat-based"
    elif grep -iq "suse\|opensuse" /usr/lib/os-release; then
        DISTRO="SUSE-based"
    else
        DISTRO="Unknown"
    fi
    log_output "Detected Distribution: $DISTRO"
}

# Detect Linux distribution and log it
detect_distribution

# Main script logic
log_output "Setting up and executing user creation tests..."

# Execute Atomic Test #1: Create a user account on Linux
create_linux_user "$DEFAULT_USERNAME"
cleanup_linux_user "$DEFAULT_USERNAME"

# Execute Atomic Test #6: Create a new user in Linux with root UID and GID
create_linux_user_with_root_gid "butter" "$DEFAULT_PASSWORD"
cleanup_linux_user_with_root_gid "butter"

log_output "All user creation tests executed."

