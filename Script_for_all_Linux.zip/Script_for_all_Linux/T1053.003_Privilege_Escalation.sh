#!/bin/bash

# Function to ensure the Linux_output/Privilege_Escalation directory exists
ensure_output_directory() {
    local output_folder="./Linux_output/Privilege_Escalation"
    mkdir -p "$output_folder"
}

# Initialize output file path
output_file="./Linux_output/Privilege_Escalation/T1053.003_Privilege_Escalation.txt"

# Detect the Linux distribution
detect_linux_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
    else
        echo "Cannot detect Linux distribution."
        exit 1
    fi
}

# Function to execute SISA Test #1
execute_SISA_test_1() {
    ensure_output_directory
    local command_SISA_1="/tmp/evil.sh"
    local tmp_cron_SISA_1="/tmp/persistevil"

    # Display progress and save to output file
    echo "Executing SISA Test #1: Replace crontab with referenced file..."
    echo "Executing command: sudo crontab -l > /tmp/notevil"
    sudo crontab -l > /tmp/notevil

    echo "* * * * * $command_SISA_1" > $tmp_cron_SISA_1
    sudo crontab $tmp_cron_SISA_1

    echo "SISA Test #1: Replace crontab with referenced file - executed successfully."
    echo "Command added to crontab: * * * * * $command_SISA_1"

    # Save to output file
    echo "SISA Test #1: Replace crontab with referenced file - executed successfully." >> "$output_file"
    echo "Command added to crontab: * * * * * $command_SISA_1" >> "$output_file"
    echo >> "$output_file"
}

# Function to execute SISA Test #2
execute_SISA_test_2() {
    ensure_output_directory
    local command_SISA_2="echo 'Hello from SISA Team' > /tmp/SISA.log"
    local cron_script_name_SISA_2="persistevil"

    # Display progress and save to output file
    echo "Executing SISA Test #2: Add script to all cron subfolders..."
    echo "$command_SISA_2" > /tmp/$cron_script_name_SISA_2

    # Copy to cron subfolders based on the detected Linux distribution
    if [ "$DISTRO" == "ubuntu" ] || [ "$DISTRO" == "debian" ]; then
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.daily/
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.hourly/
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.monthly/
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.weekly/
    elif [ "$DISTRO" == "rhel" ] || [ "$DISTRO" == "centos" ] || [ "$DISTRO" == "ol" ]; then
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.d/
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.daily/
        sudo cp /tmp/$cron_script_name_SISA_2 /etc/cron.weekly/
    fi

    echo "SISA Test #2: Add script to all cron subfolders - executed successfully."
    echo "Script added to cron subfolders:"
    echo "$command_SISA_2"

    # Save to output file
    echo "SISA Test #2: Add script to all cron subfolders - executed successfully." >> "$output_file"
    echo "Script added to cron subfolders:" >> "$output_file"
    echo "$command_SISA_2" >> "$output_file"
    echo >> "$output_file"
}

# Function to execute SISA Test #3
execute_SISA_test_3() {
    ensure_output_directory
    local command_SISA_3="*/5 * * * * root echo \"Hello from SISA Team\" > /tmp/SISA.log"
    local cron_script_name_SISA_3="persistevil"

    # Display progress and save to output file
    echo "Executing SISA Test #3: Add script to /etc/cron.d folder..."
    echo "$command_SISA_3" > /tmp/$cron_script_name_SISA_3

    # Copy to /etc/cron.d folder based on the detected Linux distribution
    if [ "$DISTRO" == "ubuntu" ] || [ "$DISTRO" == "debian" ]; then
        sudo cp /tmp/$cron_script_name_SISA_3 /etc/cron.d/
    elif [ "$DISTRO" == "rhel" ] || [ "$DISTRO" == "centos" ] || [ "$DISTRO" == "ol" ]; then
        sudo cp /tmp/$cron_script_name_SISA_3 /etc/cron.d/
    fi

    echo "SISA Test #3: Add script to /etc/cron.d folder - executed successfully."
    echo "Script added to /etc/cron.d:"
    echo "$command_SISA_3"

    # Save to output file
    echo "SISA Test #3: Add script to /etc/cron.d folder - executed successfully." >> "$output_file"
    echo "Script added to /etc/cron.d:" >> "$output_file"
    echo "$command_SISA_3" >> "$output_file"
    echo >> "$output_file"
}

# Function to execute SISA Test #4
execute_SISA_test_4() {
    ensure_output_directory
    local command_SISA_4="echo 'Hello from SISA Team' > /tmp/SISA.log"
    local cron_script_name_SISA_4="persistevil"

    # Display progress and save to output file
    echo "Executing SISA Test #4: Add script to /var/spool/cron/crontabs folder..."
    echo "$command_SISA_4" > /tmp/$cron_script_name_SISA_4

    # Copy to /var/spool/cron/crontabs based on the detected Linux distribution
    if [ "$DISTRO" == "ubuntu" ] || [ "$DISTRO" == "debian" ]; then
        sudo cp /tmp/$cron_script_name_SISA_4 /var/spool/cron/crontabs/
    elif [ "$DISTRO" == "rhel" ] || [ "$DISTRO" == "centos" ] || [ "$DISTRO" == "ol" ]; then
        sudo cp /tmp/$cron_script_name_SISA_4 /var/spool/cron/crontabs/
    fi

    echo "SISA Test #4: Add script to /var/spool/cron/crontabs folder - executed successfully."
    echo "Script added to /var/spool/cron/crontabs:"
    echo "$command_SISA_4"

    # Save to output file
    echo "SISA Test #4: Add script to /var/spool/cron/crontabs folder - executed successfully." >> "$output_file"
    echo "Script added to /var/spool/cron/crontabs:" >> "$output_file"
    echo "$command_SISA_4" >> "$output_file"
    echo >> "$output_file"
}

# Main script execution

# Detect Linux distribution
detect_linux_distro

# Execute each SISA Test function with a 5-second sleep between each
execute_SISA_test_1
sleep 5
execute_SISA_test_2
sleep 5
execute_SISA_test_3
sleep 5
execute_SISA_test_4

# Display final message and contents of output file
echo "All SISA Tests executed successfully. Output saved to: $output_file"

