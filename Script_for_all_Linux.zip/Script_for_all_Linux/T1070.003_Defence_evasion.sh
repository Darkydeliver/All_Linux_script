#!/bin/bash

# Define the output file
output_file="./Linux_output/Defence_Evasion/T1070.003_Defence_evasion_output.txt"

# Function to display current Bash history contents
display_bash_history() {
    history_path="${1:-$HOME/.bash_history}"
    echo "Current contents of ${history_path}:"
    cat "${history_path}"
    echo "-----------------------------"
}

# Atomic Test #1 - Clear Bash history (rm)
clear_bash_history_rm() {
    echo "Running SISA Test #1 - Clear Bash history (rm)"
    history_path="${1:-$HOME/.bash_history}"
    display_bash_history "${history_path}"
    rm -f "${history_path}"
    echo "Bash history cleared using 'rm'"
}

# Atomic Test #2 - Clear Bash history (echo)
clear_bash_history_echo() {
    echo "Running SISA Test #2 - Clear Bash history (echo)"
    history_path="${1:-$HOME/.bash_history}"
    display_bash_history "${history_path}"
    echo "" > "${history_path}"
    echo "Bash history cleared using 'echo'"
}

# Atomic Test #3 - Clear Bash history (cat /dev/null)
clear_bash_history_cat_dev_null() {
    echo "Running SISA Test #3 - Clear Bash history (cat /dev/null)"
    history_path="${1:-$HOME/.bash_history}"
    display_bash_history "${history_path}"
    cat /dev/null > "${history_path}"
    echo "Bash history cleared using 'cat /dev/null'"
}

# Atomic Test #4 - Clear Bash history (ln -sf /dev/null)
clear_bash_history_ln_dev_null() {
    echo "Running SISA Test #4 - Clear Bash history (ln -sf /dev/null)"
    history_path="${1:-$HOME/.bash_history}"
    display_bash_history "${history_path}"
    ln -sf /dev/null "${history_path}"
    echo "Bash history cleared using 'ln -sf /dev/null'"
}

# Atomic Test #5 - Clear Bash history (truncate)
clear_bash_history_truncate() {
    echo "Running SISA Test #5 - Clear Bash history (truncate)"
    history_path="${1:-$HOME/.bash_history}"
    display_bash_history "${history_path}"
    truncate -s 0 "${history_path}"
    echo "Bash history cleared using 'truncate'"
}

# Atomic Test #6 - Clear history of a bunch of shells
clear_history_bunch_of_shells() {
    echo "Running SISA Test #6 - Clear history of a bunch of shells"
    display_bash_history
    unset HISTFILE
    export HISTFILESIZE=0
    history -c
    echo "History cleared for all shells"
}

# Atomic Test #7 - Clear and Disable Bash History Logging
clear_disable_bash_history_logging() {
    echo "Running SISA Test #7 - Clear and Disable Bash History Logging"
    display_bash_history
    sed -i 's/set +o history//g' ~/.bashrc
    echo 'set +o history' >> ~/.bashrc
    . ~/.bashrc
    history -c
    echo "Bash history cleared and logging disabled"
    # Clean up - restore original .bashrc state
    sed -i 's/set +o history//g' ~/.bashrc
    . ~/.bashrc
    set -o history
}

# Atomic Test #8 - Use Space Before Command to Avoid Logging to History
use_space_before_command() {
    echo "Running SISA Test #8 - Use Space Before Command to Avoid Logging to History"
    display_bash_history
    # Example commands that won't be logged due to leading space
    echo " hostname"
    echo " whoami"
    echo "Commands executed with leading space to avoid logging"
}

# Function to install dependencies for different Linux distributions
install_dependencies() {
    # Check and install dependencies for Ubuntu/Debian-based systems
    if [ -f /etc/debian_version ]; then
        echo "Ubuntu/Debian detected. Installing dependencies..."
        sudo apt update
        sudo apt install -y bash coreutils
    # Check and install dependencies for RedHat/CentOS/Fedora-based systems
    elif [ -f /etc/redhat-release ]; then
        echo "RedHat/CentOS/Fedora detected. Installing dependencies..."
        sudo yum install -y bash coreutils
    # Check and install dependencies for Oracle Linux
    elif [ -f /etc/oracle-release ]; then
        echo "Oracle Linux detected. Installing dependencies..."
        sudo dnf install -y bash coreutils
    else
        echo "Unsupported Linux distribution. Please ensure bash and coreutils are installed manually."
        exit 1
    fi
}

# Function to run all atomic tests and save output
run_all_atomic_tests() {
    {
        clear_bash_history_rm "$@"
        clear_bash_history_echo "$@"
        clear_bash_history_cat_dev_null "$@"
        clear_bash_history_ln_dev_null "$@"
        clear_bash_history_truncate "$@"
        clear_history_bunch_of_shells
        clear_disable_bash_history_logging
        use_space_before_command
    } > "$output_file" 2>&1  # Redirect both stdout and stderr to the output file
}

# Main script execution
install_dependencies
run_all_atomic_tests "$@"
echo "All SISA Tests for clearing Bash history completed. Output saved to: $output_file"

