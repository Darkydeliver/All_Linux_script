#!/bin/bash

# Define the path for Linux_output directory
LinuxOutputDir="$(pwd)/Linux_output"

# Ensure Linux_output directory exists
mkdir -p "$LinuxOutputDir"

# Define the path for Persistence directory
PathToAtomicsFolder="$LinuxOutputDir/Persistence"

# Ensure Persistence directory exists
mkdir -p "$PathToAtomicsFolder"

# Define the path for T1574.006_Persistence directory
AtomicFolder="$PathToAtomicsFolder/T1574.006_Persistence"

# Ensure T1574.006_Persistence directory exists
mkdir -p "$AtomicFolder"

# Define the paths for the shared library source and object
SharedLibrarySource="$AtomicFolder/T1574.006.c"
SharedLibraryObject="$AtomicFolder/T1574006.so"

# Define output text file path
OutputLogFile="$AtomicFolder/T1574.006_Persistence.txt"

# Function to create the shared library source file
function create_shared_library_source {
    cat > "$SharedLibrarySource" <<EOF
#include <stdio.h>
#include <stdlib.h>

void init() __attribute__((constructor));

void init() {
    printf("Shared library injected for persistence via LD_PRELOAD or /etc/ld.so.preload\n");
    // Add your persistence code or functionality here
}
EOF
}

# Function to compile the shared library
function compile_shared_library {
    echo "Compiling shared library..." | tee -a "$OutputLogFile"
    gcc -shared -fPIC -o "$SharedLibraryObject" "$SharedLibrarySource" &>> "$OutputLogFile"
    if [ $? -ne 0 ]; then
        echo "Compilation failed." | tee -a "$OutputLogFile"
        exit 1
    fi
    echo "Compilation successful." | tee -a "$OutputLogFile"
}

# Function to execute Persistence Test #1 - Shared Library Injection via /etc/ld.so.preload
function execute_persistence_test_1 {
    echo "Executing SISA Test #1 - Shared Library Injection via /etc/ld.so.preload" | tee -a "$OutputLogFile"
    if [ -w /etc/ld.so.preload ]; then
        sudo sh -c "echo $SharedLibraryObject > /etc/ld.so.preload" &>> "$OutputLogFile"
        if [ $? -eq 0 ]; then
            echo "SISA Test #1 executed successfully." | tee -a "$OutputLogFile"
        else
            echo "SISA Test #1 did not execute successfully." | tee -a "$OutputLogFile"
        fi
    else
        echo "No write permissions on /etc/ld.so.preload. Ensure you are running the script with elevated privileges." | tee -a "$OutputLogFile"
    fi
}

# Function to execute Persistence Test #2 - Shared Library Injection via LD_PRELOAD
function execute_persistence_test_2 {
    echo "Executing SISA Test #2 - Shared Library Injection via LD_PRELOAD" | tee -a "$OutputLogFile"
    LD_PRELOAD="$SharedLibraryObject" ls &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "SISA Test #2 executed successfully." | tee -a "$OutputLogFile"
    else
        echo "SISA Test #2 did not execute successfully." | tee -a "$OutputLogFile"
    fi
}

# Function to clean up after tests
function cleanup {
    echo "Performing cleanup..." | tee -a "$OutputLogFile"

    # Cleanup for Persistence Test #1 - Remove from /etc/ld.so.preload
    if [ -f /etc/ld.so.preload ]; then
        sudo sed -i "s#$SharedLibraryObject##" /etc/ld.so.preload &>> "$OutputLogFile"
    fi

    # Cleanup for Persistence Test #2 - Unset LD_PRELOAD
    unset LD_PRELOAD

    # Final cleanup (optional) - Remove shared object file
    # rm -f "$SharedLibraryObject"

    echo "Cleanup complete." | tee -a "$OutputLogFile"
}

# Main script logic
echo "Setting up and executing SISA Tests..." | tee -a "$OutputLogFile"

# Ensure gcc is installed for compiling the shared library
if ! command -v gcc &>/dev/null; then
    echo "gcc is not installed. Please install gcc to proceed." | tee -a "$OutputLogFile"
    exit 1
fi

# Check if script is running with elevated privileges (for /etc/ld.so.preload modifications)
if [ "$(id -u)" -ne 0 ]; then
    echo "This script requires root privileges to modify /etc/ld.so.preload. Please run as root or with sudo." | tee -a "$OutputLogFile"
    exit 1
fi

# Create the shared library source file
create_shared_library_source

# Compile the shared library
compile_shared_library

# Execute Persistence Test #1
execute_persistence_test_1

# Execute Persistence Test #2
execute_persistence_test_2

# Clean up after tests
cleanup

echo "All SISA Tests executed." | tee -a "$OutputLogFile"

