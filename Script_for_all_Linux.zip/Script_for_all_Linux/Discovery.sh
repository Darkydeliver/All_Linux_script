#!/bin/bash

output_folder="./Linux_output/Discovery"
output_file="$output_folder/discovery_output.txt"

# Create output folders if they don't exist
mkdir -p "$output_folder" || { echo "Failed to create directory: $output_folder"; exit 1; }

# Identify Linux distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    distro=$ID
else
    distro=$(uname -s)
fi

{
    echo "Detected Linux Distribution: $distro"
    echo

    # System Owner/User Discovery - T1033
    echo "System Owner/User Discovery - T1033:"
    echo "users:"
    users
    echo
    echo "w:"
    w
    echo
    echo "who:"
    who
    echo
    
    # Enumerate all accounts (Local)
    echo "Enumerate all accounts (Local):"
    cat /etc/passwd
    echo
    
    # View sudoers access
    echo "View sudoers access:"
    if [ -f /etc/sudoers ]; then sudo cat /etc/sudoers; fi
    if [ -f /usr/local/etc/sudoers ]; then sudo cat /usr/local/etc/sudoers; fi
    echo
    
    # View accounts with UID 0
    echo "View accounts with UID 0:"
    grep 'x:0:' /etc/passwd
    grep '*:0:' /etc/passwd
    echo

    # List opened files by user
    echo "List opened files by user:"
    username=$(id -u -n)
    lsof -u $username 2>/dev/null
    echo

    # Show if a user account has ever logged in remotely
    echo "Show if a user account has ever logged in remotely:"
    [ "$distro" = "freebsd" ] && cmd="lastlogin" || cmd="lastlog"
    $cmd
    echo

    # Enumerate users and groups
    echo "Enumerate users and groups:"
    groups
    id
    echo

    # Detect Virtualization Environment
    echo "Detect Virtualization Environment:"
    if systemd-detect-virt; then echo "Virtualization Environment detected"; fi
    if sudo dmidecode | egrep -i 'manufacturer|product|vendor' | grep -iE 'Oracle|VirtualBox|VMWare|Parallels'; then echo "Virtualization Environment detected"; fi
    echo

    # System Service Discovery - systemctl/service
    echo "System Service Discovery - systemctl/service:"
    if [ "$distro" = "freebsd" ]; then
        service -e
    else
        systemctl --type=service
    fi
    echo

    # Network Share Discovery
    echo "Network Share Discovery:"
    sudo smbstatus --shares 2>/dev/null || echo "smbstatus not found or inaccessible."
    echo

    # List OS Information
    echo "List OS Information:"
    uname -a
    if [ "$distro" = "ubuntu" ]; then
        cat /etc/lsb-release
    elif [ "$distro" = "oracle" ] || [ "$distro" = "centos" ] || [ "$distro" = "rhel" ]; then
        cat /etc/redhat-release
    elif [ -f /etc/os-release ]; then
        cat /etc/os-release
    fi
    uptime
    echo

    # Linux VM Check via Hardware
    echo "Linux VM Check via Hardware:"
    if [ -f /sys/class/dmi/id/bios_version ]; then grep -i amazon /sys/class/dmi/id/bios_version; fi
    if [ -f /sys/class/dmi/id/product_name ]; then grep -i "Droplet\|HVM\|VirtualBox\|VMware" /sys/class/dmi/id/product_name; fi
    if [ -f /sys/class/dmi/id/chassis_vendor ]; then grep -i "Xen\|Bochs\|QEMU" /sys/class/dmi/id/chassis_vendor; fi
    if [ -x "$(command -v dmidecode)" ]; then sudo dmidecode | grep -i "microsoft\|vmware\|virtualbox\|quemu\|domu"; fi
    echo

    # Hostname Discovery
    echo "Hostname Discovery:"
    hostname
    echo

    # Environment variables discovery
    echo "Environment variables discovery:"
    env
    echo

    # System Network Configuration Discovery
    echo "System Network Configuration Discovery:"
    netstat -ant 2>/dev/null || echo "netstat is not available."
    arp -a 2>/dev/null || echo "arp is not available."
    ip addr || echo "ip command is missing."
    echo

    # Nix File and Directory Discovery
    echo "Nix File and Directory Discovery:"
    ls -a
    file */* 2>/dev/null || echo "File command not available."
    find . -type f 2>/dev/null
    echo

    # System Network Connections Discovery
    echo "System Network Connections Discovery:"
    netstat || echo "netstat is not available."
    who -a
    echo

    # Process Discovery - ps
    echo "Process Discovery - ps:"
    ps aux
    echo

    # Permission Groups Discovery (Local)
    echo "Permission Groups Discovery (Local):"
    getent group || echo "getent command is missing."
    cat /etc/group
    echo

    # System Task Scheduler Discovery
    echo "System Task Scheduler Discovery:"
    crontab -l || echo "No user crontab found."
    ls -la /etc/cron.d /etc/cron.* /var/spool/cron/crontabs 2>/dev/null
    echo

    # Miscellaneous Discovery
    echo "Miscellaneous Discovery:"
    find / -name '*.dat' -print 2>/dev/null
    find / -name '*.db' -print 2>/dev/null
    find / -name '*.sqlite' -print 2>/dev/null
    echo
} > "$output_file" 2>&1

echo "Output saved to $output_file"

