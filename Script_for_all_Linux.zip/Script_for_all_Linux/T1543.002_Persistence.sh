#!/bin/bash

# Ensure everything is executed in the current directory
cd "$(dirname "$0")"

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Persistence"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1543.002_Persistence.txt"

# Helper function to append output to the log file and print it
log() {
    echo "$1" | tee -a "$output_file"
}

# Function to detect Linux distribution
detect_linux_distribution() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO_NAME=$ID
        DISTRO_VERSION=$VERSION_ID
    else
        log "Cannot detect Linux distribution"
        exit 1
    fi
}

# SISA Test #1 - Create Systemd Service
log "SISA Test #1 - Create Systemd Service"

systemd_service_path="/etc/systemd/system"
systemd_service_file="sisa-systemd-service.service"
execstoppost_action="/bin/touch /tmp/sisa-systemd-execstoppost-marker"
execreload_action="/bin/touch /tmp/sisa-systemd-execreload-marker"
execstart_action="/bin/touch /tmp/sisa-systemd-execstart-marker"
execstop_action="/bin/touch /tmp/sisa-systemd-execstop-marker"
execstartpre_action="/bin/touch /tmp/sisa-systemd-execstartpre-marker"
execstartpost_action="/bin/touch /tmp/sisa-systemd-execstartpost-marker"

log "Creating Systemd service file..."
echo "[Unit]" > $systemd_service_path/$systemd_service_file
echo "Description=SISA Red Team Systemd Service" >> $systemd_service_path/$systemd_service_file
echo "" >> $systemd_service_path/$systemd_service_file
echo "[Service]" >> $systemd_service_path/$systemd_service_file
echo "Type=simple" >> $systemd_service_path/$systemd_service_file
echo "ExecStart=$execstart_action" >> $systemd_service_path/$systemd_service_file
echo "ExecStartPre=$execstartpre_action" >> $systemd_service_path/$systemd_service_file
echo "ExecStartPost=$execstartpost_action" >> $systemd_service_path/$systemd_service_file
echo "ExecReload=$execreload_action" >> $systemd_service_path/$systemd_service_file
echo "ExecStop=$execstop_action" >> $systemd_service_path/$systemd_service_file
echo "ExecStopPost=$execstoppost_action" >> $systemd_service_path/$systemd_service_file
echo "" >> $systemd_service_path/$systemd_service_file
echo "[Install]" >> $systemd_service_path/$systemd_service_file
echo "WantedBy=default.target" >> $systemd_service_path/$systemd_service_file

log "Reloading systemd daemon and enabling the service..."
systemctl daemon-reload
systemctl enable $systemd_service_file
systemctl start $systemd_service_file

log "SISA Test #1 executed successfully"

# Cleanup for SISA Test #1
log "Cleaning up SISA Test #1..."
systemctl stop $systemd_service_file
systemctl disable $systemd_service_file
rm -rf $systemd_service_path/$systemd_service_file
systemctl daemon-reload

# SISA Test #2 - Create SysV Service
log "SISA Test #2 - Create SysV Service"

rc_service_path="/etc/init.d"
rc_service_file="sisa-test"

log "Creating SysV service file..."
cat <<EOF > $rc_service_path/$rc_service_file
#!/bin/sh
#
# PROVIDE: sisa-test
# REQUIRE: LOGIN
# KEYWORD: shutdown

. /etc/rc.subr

name="sisa_test"
rcvar=sisa_test_enable
command="/usr/bin/touch"
start_cmd="sisa_test_start"

sisa_test_start()
{
  \${command} /tmp/sisa-test.marker
}

run_rc_command "\$1"
EOF

if [ -f /etc/rc.subr ]; then
    log "Setting permissions and enabling the SysV service..."
    chmod +x $rc_service_path/$rc_service_file
    service sisa-test enable
    service sisa-test start
    log "SysV service started successfully"
else
    log "SysV service test skipped: /etc/rc.subr not found"
fi

log "SISA Test #2 executed successfully"

# Cleanup for SISA Test #2
log "Cleaning up SISA Test #2..."
if [ -f /etc/rc.subr ]; then
    service sisa-test stop
    service sisa-test disable
    rm -f $rc_service_path/$rc_service_file
fi

# SISA Test #3 - Create Systemd Service file, Enable the service, Modify and Reload the service
log "SISA Test #3 - Create Systemd Service file, Enable the service, Modify and Reload the service"

log "Creating initial Systemd service file..."
cat > /etc/init.d/T1543.002 << EOF
#!/bin/bash
### BEGIN INIT INFO
# Provides : SISA Test T1543.002
# Required-Start: \$all
# Required-Stop : 
# Default-Start: 2 3 4 5
# Default-Stop: 
# Short Description: SISA Test for Systemd Service Creation
### END INIT INFO
python3 -c "import os, base64;exec(base64.b64decode('aW1wb3J0IG9zCm9zLnBvcGVuKCdlY2hvIGF0b21pYyB0ZXN0IGZvciBDcmVhdGluZyBTeXN0ZW1kIFNlcnZpY2UgVDE1NDMuMDAyID4gL3RtcC9UMTU0My4wMDIuc3lzdGVtZC5zZXJ2aWNlLmNyZWF0aW9uJykK'))"
EOF

chmod +x /etc/init.d/T1543.002
detect_linux_distribution
if [ "$DISTRO_NAME" == "ubuntu" ] || [ "$DISTRO_NAME" == "kali" ]; then
    update-rc.d T1543.002 defaults
elif [ "$DISTRO_NAME" == "centos" ] || [ "$DISTRO_NAME" == "rhel" ]; then
    chkconfig T1543.002 on
else
    log "Please run this test on Ubuntu, Kali, CentOS, or RHEL"
fi

# For systemd-based distros
if [ "$DISTRO_NAME" == "ubuntu" ] || [ "$DISTRO_NAME" == "kali" ] || [ "$DISTRO_NAME" == "centos" ] || [ "$DISTRO_NAME" == "rhel" ]; then
    systemctl enable T1543.002
    systemctl start T1543.002
fi

log "Modifying the Systemd service file..."
echo "python3 -c \"import os, base64;exec(base64.b64decode('aW1wb3J0IG9zCm9zLnBvcGVuKCdlY2hvIGF0b21pYyB0ZXN0IGZvciBtb2RpZnlpbmcgYSBTeXN0ZW1kIFNlcnZpY2UgVDE1NDMuMDAyID4gL3RtcC9UMTU0My4wMDIuc3lzdGVtZC5zZXJ2aWNhdGlvbicpCg=='))\"" | sudo tee -a /etc/init.d/T1543.002
systemctl daemon-reload
systemctl restart T1543.002

log "SISA Test #3 executed successfully"

# Cleanup for SISA Test #3
log "Cleaning up SISA Test #3..."
systemctl stop T1543.002
systemctl disable T1543.002
rm -rf /etc/init.d/T1543.002
systemctl daemon-reload

log "All tests executed. Results saved to $output_file."

