#!/bin/bash

# Cleanup script for Collection Techniques (T1560.001 and T1560.002)

# Function to clean up files created during tests
cleanup() {
    echo "Starting cleanup process..."

    # Clean up files from T1560.001 tests
    rm -f /tmp/passwd.gz
    rm -f /tmp/passwd.bz2
    rm -f /tmp/passwd.zip
    rm -f /tmp/passwd.tar.gz
    rm -f /tmp/t1560/t1560_data.zip
    rm -f /tmp/t1560/t1560_data.enc
    rm -rf /tmp/T1560

    # Clean up files from T1560.002 tests
    rm -f /tmp/passwd.bz2
    rm -f /tmp/passwd.zip
    rm -f /tmp/passwd.tar.gz
    rm -f /tmp/sisa_test1.py
    rm -f /tmp/sisa_test2.py
    rm -f /tmp/sisa_test3.py
    rm -f /tmp/sisa_test4.py

    echo "Cleanup completed."
}

# Execute cleanup
cleanup
