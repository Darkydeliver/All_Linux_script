#!/bin/bash

# Define output folder for cleanup logs
output_folder="./Linux_output/Cleanup"
mkdir -p "$output_folder"
cleanup_log="$output_folder/Cleanup_Log.txt"

# Function to cleanup for T1053.002
function cleanup_t1053_002 {
    echo "Cleaning up for T1053.002..." | tee -a "$cleanup_log"
    # Remove scheduled jobs and cleanup logs
    sudo atrm $(atq | awk '{print $1}') &>> "$cleanup_log"
}

# Function to cleanup for T1053.006
function cleanup_t1053_006 {
    echo "Cleaning up for T1053.006..." | tee -a "$cleanup_log"
    # Stop and disable the systemd service and timer
    sudo systemctl stop myservice.service &>> "$cleanup_log"
    sudo systemctl disable myservice.service &>> "$cleanup_log"
    sudo systemctl stop mytimer.timer &>> "$cleanup_log"
    sudo systemctl disable mytimer.timer &>> "$cleanup_log"
    sudo rm -f /etc/systemd/system/myservice.service &>> "$cleanup_log"
    sudo rm -f /etc/systemd/system/mytimer.timer &>> "$cleanup_log"
}

# Function to cleanup for T1059.004
function cleanup_t1059_004 {
    echo "Cleaning up for T1059.004..." | tee -a "$cleanup_log"
    # Remove temporary scripts and logs
    rm -f ./Linux_output/Execution/T1059.004_Execution*.txt &>> "$cleanup_log"
}

# Function to cleanup for T1059.006
function cleanup_t1059_006 {
    echo "Cleaning up for T1059.006..." | tee -a "$cleanup_log"
    # Remove the logs for Python execution
    rm -f ./Linux_output/Execution/T1059.006_Execution_python.txt &>> "$cleanup_log"
}

# Function to cleanup for T1098.004
function cleanup_t1098_004 {
    echo "Cleaning up for T1098.004..." | tee -a "$cleanup_log"
    # Remove SSH keys
    sed -i "/# SISA Test #1/d" ~/.ssh/authorized_keys &>> "$cleanup_log"
}

# Function to cleanup for T1546.004
function cleanup_t1546_004 {
    echo "Cleaning up for T1546.004..." | tee -a "$cleanup_log"
    # Remove entries from various profiles
    sed -i "/# SISA was here... T1546.004/d" ~/.bash_profile &>> "$cleanup_log"
    sed -i "/# SISA was here... T1546.004/d" ~/.bashrc &>> "$cleanup_log"
    sudo sed -i "/# Hello from SISA T1546.004/d" /etc/profile &>> "$cleanup_log"
    sudo sed -i "/# SISA was here... T1546.004/d" /etc/profile.d/bash_completion.sh &>> "$cleanup_log"
    sudo userdel -fr art &>> "$cleanup_log"
}

# Function to cleanup for T1547.006
function cleanup_t1547_006 {
    echo "Cleaning up for T1547.006..." | tee -a "$cleanup_log"
    # Remove the kernel module
    sudo rmmod T1547006 &>> "$cleanup_log"
    rm -f /tmp/T1547.006/T1547006.ko &>> "$cleanup_log"
}

# Function to cleanup for T1574.006
function cleanup_t1574_006 {
    echo "Cleaning up for T1574.006..." | tee -a "$cleanup_log"
    # Remove shared library from /etc/ld.so.preload
    sudo sed -i "/$(pwd)/d" /etc/ld.so.preload &>> "$cleanup_log"
    rm -f "$(pwd)/Linux_output/Privilege_Escalation/T1574.006_Privilege_Escalation/T1574006.so" &>> "$cleanup_log"
}

# Main cleanup routine
{
    echo "=========================================================="
    echo "                       Cleanup Routine                     "
    echo "=========================================================="

    cleanup_t1053_002
    cleanup_t1053_006
    cleanup_t1059_004
    cleanup_t1059_006
    cleanup_t1098_004
    cleanup_t1546_004
    cleanup_t1547_006
    cleanup_t1574_006

    echo "=========================================================="
    echo "                      Cleanup Completed                    "
    echo "=========================================================="
} | tee -a "$cleanup_log"

echo "Cleanup completed. Log saved to $cleanup_log"
