#!/bin/bash

# Ensure output directory exists
OUTPUT_DIR="Linux_output/Impact"
mkdir -p "$OUTPUT_DIR"
OUTPUT_FILE="$OUTPUT_DIR/Output.txt"

# Redirect stderr to stdout to capture all output
exec 2>&1

# Start script execution
echo "Starting comprehensive Linux script at $(date)" | tee -a "$OUTPUT_FILE"

# OS Detection for Package Management
if [ -f /etc/os-release ]; then
  . /etc/os-release
  OS=$ID
else
  OS=$(uname -s)
fi

# Test 1: T1531 - Change user password
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1531 - Change User Password" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

NEW_PASSWORD="sisa1"
USER="Bastest"

if ! id -u "$USER" >/dev/null 2>&1; then
  echo "User $USER does not exist. Creating user..." | tee -a "$OUTPUT_FILE"
  useradd -m -s /bin/bash "$USER"
  if [ $? -eq 0 ]; then
    echo "User $USER created successfully." | tee -a "$OUTPUT_FILE"
  else
    echo "Error: Failed to create user $USER." | tee -a "$OUTPUT_FILE"
    exit 1
  fi
else
  echo "User $USER already exists." | tee -a "$OUTPUT_FILE"
fi

echo "Changing password for user $USER..." | tee -a "$OUTPUT_FILE"
echo -e "$NEW_PASSWORD\n$NEW_PASSWORD" | passwd "$USER" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "Password for user $USER changed successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to change password for user $USER." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 2: T1486 - Encrypt files using gpg
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1486 - Encrypt Files Using GPG" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

GPG_FILE_PATH="${PWD}/T1486_passwd.gpg"
INPUT_FILE="/etc/passwd"
PASSPHRASE="localsupport"

echo "Encrypting $INPUT_FILE using gpg with passphrase $PASSPHRASE..." | tee -a "$OUTPUT_FILE"
echo "$PASSPHRASE" | gpg --batch --yes --passphrase-fd 0 --cipher-algo AES-256 -o "$GPG_FILE_PATH" -c "$INPUT_FILE" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "File encrypted successfully. Encrypted file saved at $GPG_FILE_PATH." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to encrypt file with gpg." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 3: Encrypt files using 7z
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1486 - Encrypt Files Using 7z" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

# Install p7zip if not installed
if ! command -v 7z &> /dev/null; then
  echo "p7zip not found. Installing..." | tee -a "$OUTPUT_FILE"
  case $OS in
    "ubuntu"|"debian"|"kali")
      apt-get update && apt-get install -y p7zip-full
      ;;
    "centos"|"redhat"|"oracle")
      yum install -y p7zip
      ;;
    "fedora")
      dnf install -y p7zip
      ;;
    "arch")
      pacman -S --needed p7zip
      ;;
    *)
      echo "Unsupported Linux distribution: $OS" | tee -a "$OUTPUT_FILE"
      exit 1
      ;;
  esac
fi

SEVEN_ZIP_FILE_PATH="${PWD}/T1486_Encrypt_using_7z.zip"
echo "Encrypting $INPUT_FILE using 7z with passphrase $PASSPHRASE..." | tee -a "$OUTPUT_FILE"
7z a -p${PASSPHRASE} "$SEVEN_ZIP_FILE_PATH" "$INPUT_FILE" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "File encrypted successfully. Encrypted file saved at $SEVEN_ZIP_FILE_PATH." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to encrypt file with 7z." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 4: RSA encryption
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1486 - RSA Encryption" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

OPENSSL_CMD=$(which openssl)
PRIVATE_KEY_PATH="/tmp/key.pem"
PUBLIC_KEY_PATH="/tmp/pub.pem"
ENCRYPTED_FILE_PATH="${PWD}/RSA_passwd.zip"
ENCRYPTION_BIT_SIZE=2048

echo "Generating RSA keys..." | tee -a "$OUTPUT_FILE"
$OPENSSL_CMD genrsa -out "$PRIVATE_KEY_PATH" "$ENCRYPTION_BIT_SIZE" 2>&1 | tee -a "$OUTPUT_FILE"
$OPENSSL_CMD rsa -in "$PRIVATE_KEY_PATH" -pubout -out "$PUBLIC_KEY_PATH" 2>&1 | tee -a "$OUTPUT_FILE"

echo "Encrypting $INPUT_FILE using RSA public key..." | tee -a "$OUTPUT_FILE"
$OPENSSL_CMD rsautl -encrypt -inkey "$PUBLIC_KEY_PATH" -pubin -in "$INPUT_FILE" -out "$ENCRYPTED_FILE_PATH" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "File encrypted successfully. Encrypted file saved at $ENCRYPTED_FILE_PATH." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to encrypt file with RSA." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 5: T1496 - Resource exhaustion
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1496 - Resource Exhaustion" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

echo "Starting resource exhaustion test using 'yes' command..." | tee -a "$OUTPUT_FILE"
yes > /dev/null &
YES_PID=$!
echo "PID of 'yes' command: $YES_PID" | tee -a "$OUTPUT_FILE"
sleep 10
kill $YES_PID
echo "Resource exhaustion test completed." | tee -a "$OUTPUT_FILE"

# Test 6: T1485 - Overwrite file with DD
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1485 - Overwrite File with DD" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

OVERWRITE_SOURCE="${PWD}/tooverwrite.txt"
FILE_TO_OVERWRITE="${PWD}/toremove.txt"

echo "This is a sample text file to overwrite the data to remove the content of the file." > "$OVERWRITE_SOURCE"
echo "Hi, this is file to be overwritten by the script..." > "$FILE_TO_OVERWRITE"

echo "Overwriting $FILE_TO_OVERWRITE with $OVERWRITE_SOURCE using dd..." | tee -a "$OUTPUT_FILE"
dd of="$FILE_TO_OVERWRITE" if="$OVERWRITE_SOURCE" count=$(ls -l "$FILE_TO_OVERWRITE" | awk '{print $5}') iflag=count_bytes 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "File overwritten successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to overwrite file with dd." | tee -a "$OUTPUT_FILE"
  exit 1
fi

echo "Comprehensive Linux script completed at $(date)" | tee -a "$OUTPUT_FILE"

