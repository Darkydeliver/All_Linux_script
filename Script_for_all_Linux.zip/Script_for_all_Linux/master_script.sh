#!/bin/bash
# Display Banner
display_banner() {
    GREEN='\033[0;32m'
    Blue='\033[0;34m'
    White='\033[1;37m'
    echo ""
    echo -e "${Blue}  ____ ___ ____    _        _     ___ _   _ _   ___  __    ____    _    ____  "
    echo -e "${Blue} / ___|_ _/ ___|  / \      | |   |_ _| \ | | | | \ \/ /   | __ )  / \  / ___| "
    echo -e "${Blue} \___ \| |\___ \ / _ \     | |    | ||  \| | | | |\  /    |  _ \ / _ \ \___ \ "
    echo -e "${Blue}  ___) | | ___) / ___ \    | |___ | || |\  | |_| |/  \    | |_) / ___ \ ___) |"
    echo -e "${Blue} |____/___|____/_/   \_\___|_____|___|_| \_|\___//_/\_\___|____/_/   \_\____/ "
    echo -e "${Blue}                      |_____|                        |_____|                  "
    echo -e "${White}"
}

# Function to ensure the Linux_output directory exists
ensure_output_directory() {
    local output_folder="./Linux_output"
    mkdir -p "$output_folder"
}



# Function to execute the Discovery script
execute_discovery() {
    ensure_output_directory
    echo "Executing Discovery.sh"
    bash "./Discovery.sh"
    echo "Execution of Discovery.sh complete."
}

# Function to execute Execution scripts with a timeout
execute_execution() {
    echo "Initiating Execution...."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local techniques=(
        "T1053.002_Execution"
        "T1053.003_Execution"
        "T1053.006_Execution"
        "T1059.006_Execution_python"
        "T1059.004_Execution"
    )

    for technique in "${techniques[@]}"; do
        echo "Executing $technique"
        timeout 300 bash "./$technique.sh"
        if [ $? -eq 124 ]; then
            echo "Execution of $technique timed out."
        fi
        echo "Execution of $technique complete."
    done
}

# Function to execute Defense Evasion scripts with a delay
execute_defense_evasion() {
    echo "Initiating Defence Evasion...."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local scripts=(
        "T1014_3_Defence_evasion.sh" 
        "T1014_4_Defence_evasion.sh"
        "T1027.004_Defence_evasion.sh" 
        "T1036.003_Defence_evasion.sh"
        "T1036.004_Defence_evasion.sh"
        "T1036.005_Defence_evasion.sh"
        "T1036.006_Defence_evasion.sh"
        "T1070.003_Defence_evasion.sh"
        "T1070.004_Defence_evasion.sh"
        "T1078.003_Defence_evasion.sh"
        "T1547.006_Defence_evasion.sh"
        "T1548.001_Defence_evasion.sh"
        "T1553.004_Defence_evasion.sh"
        "T1562.004_Defence_evasion.sh"
        "T1562.012_Defence_evasion.sh"
        "T1564.001_Defence_evasion.sh"
    )

    for script in "${scripts[@]}"; do
        if [ -f "$script" ]; then
            echo "Executing $script"
            bash "./$script"
            echo "Execution of $script complete."
            sleep 2 # Add an 8-second delay between scripts
        else
            echo "$script not found in the current directory."
        fi
    done
}

# Function to execute Credential Access scripts
execute_credential_access() {
    echo "Initiating Credential Access...."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local scripts=(
        "T1040_Credential_access.sh"
        "T1040_pc_Credential_access.sh"
        "T1552.003_Credential_access.sh"
        "T1003.007_Credential_access.sh"
        "T1003.008_Credential_access.sh"
        "T1056.001_Credential_access.sh"
        "T1110.001_Credential_access.sh"
    )

    for script in "${scripts[@]}"; do
        if [ -f "$script" ]; then
            echo "Executing $script"
            bash "./$script"
            echo "Execution of $script complete."
            sleep 2  # Add an 8-second delay between scripts
        else
            echo "$script not found in the current directory."
        fi
    done
}

# Function to execute Privilege Escalation scripts
execute_privilege_escalation() {
    echo "Initiating Privilege Escalation....."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local escalation_scripts=(
        "T1037.004_Privilege_Escalation.sh"
        "T1053.002_Privilege_Escalation.sh"
        "T1053.003_Privilege_Escalation.sh"
        "T1053.006_Privilege_Escalation.sh"
        "T1078.003_Privilege_Escalation.sh"
        "T1098.004_Privilege_Escalation.sh"
        "T1547.006_Privilege_Escalation.sh"
        "T1546.004_Privilege_Escalation.sh"
        "T1548.001_Privilege_Escalation.sh"
        "T1574.006_Privilege_Escalation.sh"
    )

    for script in "${escalation_scripts[@]}"; do
        if [ -f "$script" ]; then
            echo "Executing $script"
            bash "./$script"
            echo "Execution of $script complete."
            sleep 2  # Add an 8-second delay between scripts
        else
            echo "$script not found in the current directory."
        fi
    done
}

# Function to execute Persistence scripts
execute_persistence() {
    echo "Initiating Persistence...."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local persistence_scripts=(
        "T1543.002_Persistence.sh"
        "T1053.003_Persistence.sh"
        "T1136.001_Persistence.sh"
        "T1574.006_Persistence.sh"
        "T1098.004_Persistence.sh"
        "T1053.006_Persistence.sh"
        "T1546.004_Persistence.sh"
        "T1037.004_Persistence.sh"
        "T1053.002_Persistence.sh"
        "T1078.003_Persistence.sh"
    )

    for script in "${persistence_scripts[@]}"; do
        if [ -f "$script" ]; then
            echo "Executing $script"
            bash "./$script"
            echo "Execution of $script complete."
            sleep 2  # Add an 8-second delay between scripts
        else
            echo "$script not found in the current directory."
        fi
    done
}

# Function to execute Collection scripts
execute_collection() {
    echo "Initiating Collection...."
    #sleep 90  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local collection_scripts=(
        "T1074.001_Collection.sh"
        "T1056.001_Collection.sh"
        "T1113_Collection.sh"
        "T1560.001_Collection.sh"
        #"T1115_Collection.sh"
        "T1560.002_Collection.sh"
    )

    for script in "${collection_scripts[@]}"; do
        if [ -f "$script" ]; then
            echo "Executing $script"
            bash "./$script"
            echo "Execution of $script complete."
            sleep 2  # Add an 8-second delay between scripts
        else
            echo "$script not found in the current directory."
        fi
    done
}

# Function to execute Impact scripts
execute_impact() {
    echo "Initiating Impact...."
    #sleep 10  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local impact_script="Impact.sh"
    if [ -f "$impact_script" ]; then
        echo "Executing $impact_script"
        bash "./$impact_script"
        echo "Execution of $impact_script complete."
    else
        echo "$impact_script not found in the current directory."
    fi
}

# Function to execute Exfiltration scripts
execute_exfiltration() {
    echo "Initiating Exfiltration...."
    #sleep 90  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local exfiltration_script="Exfiltration.sh"
    if [ -f "$exfiltration_script" ]; then
        echo "Executing $exfiltration_script"
        bash "./$exfiltration_script"
        echo "Execution of $exfiltration_script complete."
    else
        echo "$exfiltration_script not found in the current directory."
    fi
}

# Function to execute Network Simulation script
execute_network_simulation() {
    echo "Initiating Network Simulation...."
    #sleep 90  # Sleep for 1.30 minutes (90 seconds) 
    ensure_output_directory
    local network_simulation_script="Network_Simulation.sh"
    if [ -f "$network_simulation_script" ]; then
        echo "Executing $network_simulation_script"
        bash "./$network_simulation_script"
        echo "Execution of $network_simulation_script complete."
    else
        echo "$network_simulation_script not found in the current directory."
    fi
}

# Main menu function
main_menu() {
    while true; do
        clear
        display_banner
        echo "Please select a task to execute:"
        echo "0) Execute All"
        echo "1) Discovery"
        echo "2) Execution"
        echo "3) Defense Evasion"
        echo "4) Credential Access"
        echo "5) Privilege Escalation"
        echo "6) Persistence"
        echo "7) Collection"
        echo "8) Impact"
        echo "9) Network Simulation"
        echo "10)Exfiltration"
        echo "Q) Quit"
        read -p "Enter your choice: " choice

        case $choice in
            0)
                execute_discovery
                execute_execution
                execute_defense_evasion
                execute_credential_access
                execute_privilege_escalation
                execute_persistence
                execute_collection
                execute_impact
                execute_network_simulation
                execute_exfiltration
                echo "All scripts completed. Press Enter to continue..."
                read
                ;;
            1)
                execute_discovery
                echo "Discovery script completed. Press Enter to continue..."
                read
                ;;
            2)
                execute_execution
                echo "Execution scripts completed. Press Enter to continue..."
                read
                ;;
            3)
                execute_defense_evasion
                echo "Defense Evasion scripts completed. Press Enter to continue..."
                read
                ;;
            4)
                execute_credential_access
                echo "Credential Access scripts completed. Press Enter to continue..."
                read
                ;;
            5)
                execute_privilege_escalation
                echo "Privilege Escalation scripts completed. Press Enter to continue..."
                read
                ;;
            6)
                execute_persistence
                echo "Persistence scripts completed. Press Enter to continue..."
                read
                ;;
            7)
                execute_collection
                echo "Collection scripts completed. Press Enter to continue..."
                read
                ;;
            8)
                execute_impact
                echo "Impact script completed. Press Enter to continue..."
                read
                ;;
            9)
                execute_network_simulation
                echo "Network Simulation completed. Press Enter to continue..."
                read
                ;;
            10)
                execute_exfiltration
                echo "Exfiltration script script completed. Press Enter to continue..."
                read
                ;;
            [Qq])
                echo "Quitting..."
                break
                ;;
            *)
                echo "Invalid choice. Please try again."
                ;;
        esac
    done
}

# Execute the main menu
main_menu

