#!/bin/bash
 
# Install auditd if not installed
if ! command -v auditd &> /dev/null
then
    echo "auditd not found, installing..."
    sudo apt update
    sudo apt install -y auditd audispd-plugins
fi
 
# Start and enable auditd
sudo systemctl start auditd
sudo systemctl enable auditd
 
# Add audit rule to log all command executions
AUDIT_RULE64="-a always,exit -F arch=b64 -S execve -k all_commands"
AUDIT_RULE32="-a always,exit -F arch=b32 -S execve -k all_commands"
 
if ! sudo grep -q "$AUDIT_RULE64" /etc/audit/rules.d/audit.rules; then
    echo "Adding audit rule to log all command executions (64-bit)"
    echo "$AUDIT_RULE64" | sudo tee -a /etc/audit/rules.d/audit.rules
fi
 
if ! sudo grep -q "$AUDIT_RULE32" /etc/audit/rules.d/audit.rules; then
    echo "Adding audit rule to log all command executions (32-bit)"
    echo "$AUDIT_RULE32" | sudo tee -a /etc/audit/rules.d/audit.rules
fi
 
# Restart auditd to apply the rules
sudo systemctl restart auditd
echo "Auditd setup complete. All command executions will be logged to /var/log/audit/audit.log."
